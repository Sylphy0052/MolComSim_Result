#!/bin/bash

rm -r compare* regression*
rm result/*.png
rm result/time.txt
rm index.html
rm pickle_file*
