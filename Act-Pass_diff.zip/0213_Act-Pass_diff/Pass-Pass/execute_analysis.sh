#!/bin/bash

python src/execute_analysis.py
